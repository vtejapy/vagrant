def foo(): print "foo from name2.py"

