"""
  sdfjlsd jflksd jflksd jlkfs djlkfjsdlkfj sdlkf
  lskd flksdj flksdj flksdj flksdj flksdf
  owe uroiweuroiweu roiweu oiuweoiruewr
"""

#import math
from math import *

name = "sam"

def greet(): print "Hello world"

