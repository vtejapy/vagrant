i = 0
while i < 4:
    print i
    i += 1
    if i % 4 == 0: 
        break
else:
    print "Loop condition failed."

print "End of loop"
