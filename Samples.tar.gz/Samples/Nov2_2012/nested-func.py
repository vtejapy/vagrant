#!/usr/bin/env python

def calculate(operation, val1, val2):
    def add(x, y):
	return x+y
    def mul(x, y):
      	return x*y
    if (operation == '+'):
       	return add(val1, val2)  
    elif (operation == 'x'):
      	return mul(val1, val2)

print calculate('+', 10, 20)