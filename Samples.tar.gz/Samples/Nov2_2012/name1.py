
def foo():
    print "This is foo function..."
    print "In foo: namespace is", __name__

if __name__ == '__main__': foo()



