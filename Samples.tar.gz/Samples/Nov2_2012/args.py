#!/usr/bin/env python
import sys
for i, arg in enumerate(sys.argv):
	print i, "->", arg
