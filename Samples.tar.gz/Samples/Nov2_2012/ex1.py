import sys

a = 10
b = 0

print "Begining of program..."
try:
    print "In try block..."
    c = a / 1 
    raise ValueError, "invalid value" 
    print "Completed division..."
except ZeroDivisionError, msg:
    print "Got Divide by Zero error:", msg
except ValueError, msg:
    print "Got value error:", msg
except:
    print "Block raised an exception..."
    #print "Exception info", sys.exc_info()
else:
    print "No exception thrown..."
finally:
    print "Cleanup operations..."


print "Continuing with program..."
#sys.exc_clear()
#print sys.exc_info()
