#!/usr/bin/env python
from time import time

start = time()
i = 0L
for i in xrange(10000000000000000000000000000000): pass
end = time()

print "Duration: ", end - start


