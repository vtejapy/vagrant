#!/usr/bin/env python
import sys

def test1():
	print "This is test case 1..."

def test2():
	print "This is test case 2..."

def alpha():
	print "This is alpha test case..."

def quit():
	sys.exit(0)


while True:
	m = input("Enter test case: ")
	m()

