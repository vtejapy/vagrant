#!/usr/bin/env python
import sys

try:
	print "In try block..."
	if sys.argv[1] == "a":
		raise ValueError
	elif sys.argv[1] == "b":
		raise KeyError
	else:
		print "No exceptions thrown..."
except ValueError:
	print "Caught value error"
except KeyError:
	print "Caught key error"
else:
	print "This is the else block"
finally:
	print "This is a finally block"

print "End of program"

