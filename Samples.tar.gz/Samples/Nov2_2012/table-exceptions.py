try:
    exit(1)
    print a
    num = int(raw_input("Enter a number: "))
except ValueError, e:
    print "Invalid input - ", e
    exit(1)
except NameError, e:
    print "Invalid variable - ", e
    exit(1)
finally:
    print "Cleanup done."



for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
    print num, "x", i, "=", num*i


