#!/usr/bin/env python

def foo():
   a = 10
   b = "hello world"
   print "-" * 40
   print locals()
   print "-" * 40
   print globals()


name = "john"
age = 20
foo()

