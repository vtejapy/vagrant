from math import sqrt

def isprime(x):
    for i in range(2, int(sqrt(x))+1):
        if x % i == 0:
            return False
    else:
        return True


num = input("Enter a number: ")
factors = [ x for x in xrange(2, (num/2)+1) if (num % x == 0) and isprime(x) ]


if factors:
    print factors
else:
    print "No prime factors for", num






