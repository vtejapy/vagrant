#!/usr/bin/env python

def calculate(operation):

    def add(x, y):
        return x+y

    def mul(x, y):
      	return x*y
    
    if (operation == '+'):
       	return add
    elif (operation == 'x'):
      	return mul

c = calculate("+")
d = calculate("x")

print c(10, 20)
print d(10, 20)

