import math

import name3

print len("hello")

name3.foo()

print math.sqrt(4)

