def list_dir(): print "Listing contents of directory"

def show_pwd(): print "/root"

def show_hostname(): print "localhost"

def show_date(): print "Fri Nov 2 2012"

def show_username(): print "root"

commands = {
    "ls"       : list_dir,
    "pwd"      : show_pwd,
    "hostname" : show_hostname,
    "date"     : show_date,
    "whoami"   : show_username
}


while True:
    cmd = raw_input("shell> ")
    if cmd == "exit": break
    if cmd in commands:
        commands[cmd]()
    else:
        print "Invalid command -", cmd

