a = 100

def foo():
    a = 20
    print "In foo function: a = ", a
    def bar():
        print "In bar function a = ", a
        #a = 30
    
    return bar


b = foo()
print "Calling bar function..."
b()


