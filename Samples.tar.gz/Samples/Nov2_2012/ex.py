
def foo():
    n = int(raw_input("Enter a number: "))
    print "Got a value: ", n

