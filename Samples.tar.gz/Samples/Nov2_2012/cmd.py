def listdir(args):
    print "Called listdir with", args

def showdate(args):
    print "Called showdate with", args

def pwd(args):
    print "Called pwd with", args

def showhostname(args):
    print "Called showhostname with", args

def invalid_command(args):
    print "Invalid command"

# ls -> listdir, date -> showdate, pwd -> pwd, hostname -> showhostname

commands = {
        "ls" : listdir,
        "date" : showdate,
        "pwd" : pwd,
        "hostname" : showhostname
}


while True:
    cmd = raw_input("CMD> ")
    args = cmd.split(" ")
    c = args.pop(0)
    func = commands.get(c, invalid_command)
    func(args)


