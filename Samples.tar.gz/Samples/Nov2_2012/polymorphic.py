#!/usr/bin/env python

import types

def square(x):
    if type(x) is int:
        return x*x
    elif type(x) is float:
        return x*x
    else:
        raise Exception, "Numeric value expected"


print square(10)

print square("This")

 
