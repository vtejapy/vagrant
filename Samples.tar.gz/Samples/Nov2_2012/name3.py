import math

def len(x): return 100

def mysqrt(x): return 10

math.sqrt = mysqrt

def foo():
    print len("test string")

