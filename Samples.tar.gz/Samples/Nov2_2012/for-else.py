#!/usr/bin/env python

names = ["Alan", "John", "Smith", "Jones", "Sam"]
search = raw_input("Enter a name to search: ")

#for n in names:
#	if n == search: 
#		print "Found!"
#		break
#else:
#	print "Not found..."
#
#print "End"

#found = False

#for n in names:
#    if n == search:
#        found = True
#        break
#
#if found:
#    print "Found!"
#else:
#    print "Not found"

if search in names: 
    print "Found"
else:
    print "Not found"


