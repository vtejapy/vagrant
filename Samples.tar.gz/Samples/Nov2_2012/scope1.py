
a = 10

def foo():
    global a
    print "In foo: a = ", a, id(a)
    a = 100
    print "In foo: a = ", a, id(a)

print "In main: a = ", a, id(a)
foo()
print "In main: a = ", a, id(a)

