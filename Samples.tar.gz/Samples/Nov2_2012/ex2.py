import ex

ex.foo()

