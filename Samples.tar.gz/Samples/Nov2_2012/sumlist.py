def sumlist(*nums):
    total = 0
    for i in nums:
        total += i
    return total


#print sumlist(10, 20)
#print sumlist(44, 55, 66, 77, 88, 99)
#print sumlist(10)

print sumlist(10, 20)
print sumlist(44, 55, 66, 77, 88, 99)
print sumlist(10)
