names = (
    ("john", "sam", "jones", "jane"),
    ("adam", "bourne", "smith", "adrian"),
    ("larry", "steve", "dennis", "rossum")
)

n = raw_input("Enter name: ")

for rec in names:
    if n in rec: 
        print n, "found"
        break
        for i in range(10):
            print i
else: # for loop DO NOT re-indent
    print n, "not found"    
