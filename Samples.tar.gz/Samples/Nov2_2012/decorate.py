

def log(f):
    print "Calling function: ", f
    print "-" * 20
    f()
    print "Function complete."

@log
def greet():
    print "Hello world"

@log
def welcome():
    print "Welcome to Python"



