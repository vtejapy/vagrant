#def greet(name="Guest", city="Bengaluru"):
#    print "Hello", name, "Welcome to", city

#greet()
#greet("John")
#greet("John", "Delhi")
#greet(100)


#def greet(*names):
#    for n in names: print "Hello", n
#    print "-" * 10
#
#
#greet ("john");
#greet ("john", "sam", "jones")
#greet ("smith", "bourne", "adam", "jane", "bill")


#def greet(name, city="Delhi", *numbers):
#    print "Name: %s, city: %s" % (name, city)
#    print "Numbers: ", numbers
#
#greet("john", "mumbai", 33, 44, 55, 66)


#def greet(name, city, dept):
#    print "Name: {0}, City: {1}, Dept: {2}".format(name, city, dept)

#greet("john", dept="IT", city="Delhi")

#records = [("john", "delhi", "IT"), ("bourne", "mumbai", "Support"), ("sam", "chennai", "Marketing")]

#for r in records:
#    greet(*r)


def greet(name, **args):
    print "Name: ", name
    for k, v in args.items(): print k, "=", v

greet("john", name="sam", city="delhi", age=40, dept="IT")

























































