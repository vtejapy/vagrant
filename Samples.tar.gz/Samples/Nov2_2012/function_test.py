def add_record(name, age, city='Bengaluru'):
    print "Name:", name, ", Age:", age, ", City:", city  

add_record("john", 10, "Delhi")
#add_record(10, "Delhi", "Smith")
add_record(age=10, city="Mumbai", name="Smith")

add_record(age=10, name="Smith")
add_record("Smith", 45)
