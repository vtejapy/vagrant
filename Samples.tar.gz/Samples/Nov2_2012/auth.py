#!/usr/bin/env python
name = raw_input("Enter your name: ")
if name == "john":
        print "Hello ", name
   	print "Welcome to python"
else:
	print "Invalid user..."

print "End of program"

