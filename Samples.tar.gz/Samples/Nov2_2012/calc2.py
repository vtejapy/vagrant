def add(x, y):
    return x + y

def sub(x, y):
    return x - y

def mul(x, y):
    return x * y

def pow(x, y):
    return x ** y


tasks = [add, sub, mul, pow]

data = [60, 10]

for t in tasks:
    print t(*data)

