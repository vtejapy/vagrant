db = sql.connect("...")

try:
    db.begin_transaction()
    db.execute(q1)
    ....
    db.execute(q1)
except SQLError, e:
    db.rollback()
else:
    db.commit()
finally:
    db.close()

