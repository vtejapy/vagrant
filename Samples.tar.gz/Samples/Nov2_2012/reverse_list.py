a = [10, 20, 30, 40, 50, 60, 70]

def reverse_list(x):
    l = len(x)
    while l:
        l -= 1
        yield x[l]

for i in reverse_list(a): print i,

