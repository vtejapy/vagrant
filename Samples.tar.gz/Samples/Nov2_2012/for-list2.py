#!/usr/bin/env python
import sys

names = [ [ "john", "sam", "smith", "jones"],
          [ "sarah", "larry", "williams", "steve"],
          [ "adrian", "adam", "bourne", "murdock" ] ]

name = input("Enter a name: ")
for row in names:
	if name in row: 
		print "Found"
		break
else:   # DO NOT INDENT THIS... MEANT FOR FOR LOOP
	print "Not found"
		
	
