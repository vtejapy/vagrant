#!/usr/bin/env python
last_num = input("Enter a number: ")

num = 1
while num < 10:
    print "Hello"
    num += 1
    if num == last_num: 
        break
else:
    print "Cannot print beyond 10 times..."

print "End of program"

