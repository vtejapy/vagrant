while True:
    try:
        age = input("Enter your age: ")
    except:
        print "Invalid age... please type again."
    else:
        break

if age <= 0:
    print "Which planet are you from,", name, "?"
elif age > 0 and age <= 10:
    print "Hi kid!"
elif age > 10 and age <= 30:
    print "Welcome, young programmer"
elif age > 30 and age <= 60:
    print "Hello sir!"
elif age > 60 and age <= 120:
    print "Hi old man! How are you doing today"
else:
    print "Are you from planet earth,", name, "?"

print "End of program"



