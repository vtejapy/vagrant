name = raw_input("Enter your name: ")
if not ((name == "john") or (name == "sam")):
    print "Hello", name
elif name == "smith":
    print "Greetings, Smith..."
    print "Nice to meet you again."
elif name == "bourne":
    print "Hi Bourne..."
else:
    print "Hello guest"

print "End of program"



