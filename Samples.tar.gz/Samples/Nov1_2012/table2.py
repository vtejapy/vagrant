while True:
   try:
      number = int(raw_input("Enter a number: "))
      break
   except ValueError, e:
      print "Invalid number!"

# Iterate i in a tuple of 1 to 10
for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
    print number, "x", i, "=", number*i
print "-" * 10
    print "Hello world"


