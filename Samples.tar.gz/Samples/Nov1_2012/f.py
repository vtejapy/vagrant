n = input("Enter number of series: ")

def fibo(num):
    a, b = 0, 1
    for i in range(num):
        print a, 
        a, b = b, a + b

def square(x): return x*x

fibo(n)

print "\n", square(n)

