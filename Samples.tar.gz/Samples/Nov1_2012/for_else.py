names = "sam", "jones", "john", "adam", "bourne", "steve"

n = raw_input("Enter name to search: ")
for i in names:
    if i == n:
        print "Found."
        break
else:
    print "Not found."

print "End of program..."

