for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
    print "i =", i
    if i % 3 == 0:
        print i, "is divisible by 3"
   print "---------"


