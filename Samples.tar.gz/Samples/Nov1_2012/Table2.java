import java.math.*;

public class Table2 {
	public static void main(String[] args) {
		if (args.length < 1) {
			System.err.println("usage: java Table <number>");
			return;
		}
		BigInteger num = new BigInteger(args[0]);
		for (int count=1; count<=10; count++) {
		    BigInteger result = 
                             num.multiply(new BigInteger(Integer.toString(count)));
			System.out.print(num.toString());
			System.out.print(" x ");
			System.out.print(count);
			System.out.print(" = ");
			System.out.print(result.toString());
			System.out.print("\n");
		}
	}
}
