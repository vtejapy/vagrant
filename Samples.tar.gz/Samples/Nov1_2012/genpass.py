import string
import random
chars = list(string.ascii_letters + string.digits)
random.shuffle(chars)
print "".join(chars)[:8]
