print "Hello world"
# OUT: Hello world
for i in 1,2,3,4:
    print i
    

# OUT: 1
# OUT: 2
# OUT: 3
# OUT: 4
