import sys
import string

if len(sys.argv) > 1:
    num_input = sys.argv[1]
else:
    num_input = raw_input("Enter a number: ")

for ch in num_input:
    if ch not in string.digits:
        print "Invalid character: ", ch
        sys.exit(-1)
else:
    num = int(num_input)

for i in range(1,11):
    print num, " x ", i, " = ", num*i
