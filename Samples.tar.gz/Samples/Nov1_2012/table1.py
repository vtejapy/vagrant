while True:
    try:
        num = int(raw_input("Enter a number: "))
        break
    except NameError:
        print "Invalid variable..."
    except KeyError:
        print "Invalid key..."
    except ValueError:
        print "*** Invalid number ***"
    except:
        print "Some unknown error..."

for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
    print num, "x", i, "=", num*i


