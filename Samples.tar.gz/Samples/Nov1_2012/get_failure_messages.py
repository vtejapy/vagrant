with open("/var/log/messages") as log:
	for line in log.xreadlines():
		if "failure" in line:
			print line

