i = 10
print i

for i in [1, 2, 3, 4, 5]:
    if (i%2) == 0:
        print i
        if i == 4:
           print i
         
    print "..."

print "END"

