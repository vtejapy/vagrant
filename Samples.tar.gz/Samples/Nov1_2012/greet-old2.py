#!/usr/bin/env python
name = raw_input("Enter your name: ")
print "Hello " + name

age = int(raw_input("Enter your age: "))

print "You will live for another " + (age*10) + "times"

