#!/usr/bin/env python
def test1():
    def greet():
        print "Hello world"
    greet()


