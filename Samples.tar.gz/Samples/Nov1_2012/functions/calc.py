def calc(op):
    if op == "add":
        def task(x, y):
            return x + y
    elif op == "sub":
        def task(x, y):
            return x - y
    elif op == "mul":
        def task(x, y):
            return x*y
    else:
       raise TypeError, "Invalid operation"

    return task


operation = calc("add")
print operation(10, 20)

operation = calc("sub")
print operation(40, 10)

