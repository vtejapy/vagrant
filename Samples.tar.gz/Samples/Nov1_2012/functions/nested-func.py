#!/usr/bin/env python

def calculate(operation, val1, val2):
    if (operation == '+'):
        def add(x, y):
            return x+y
       	return add(val1, val2)  
    elif (operation == 'x'):
        def mul(x, y):
      	    return x*y
      	return mul(val1, val2)

print calculate('+', 10, 20)
print calculate('x', 10, 20)
print mul(10, 20)

