def calc_factory(x):
   
    if x == "adder":
       def calc(x, y): return x+y
    elif x == "subtractor":
       def calc(x, y): return x-y
    elif x == "multiplier":
       def calc(x, y): return x*y
    else:
       raise ValueError, "need either adder/subtractor/multiplier as parameter"

    return calc
 


