def add_record(**args):
    name = args.get("name", "Guest")
    age = args.get("age", 0)
    city = args.get("city", "Bengaluru")

    print "Name: %s, Age: %d, City: %s" % (name, age, city)



add_record(name="john", age=10, city="Mumbai", car="Honda")
add_record(name="smith")


