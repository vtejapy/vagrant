#!/usr/bin/env python
import fileinput
import sys
for line in fileinput.input():
	num = fileinput.lineno()
	output = "%04d %s" % (num, line)
        sys.stdout.write(output)

	