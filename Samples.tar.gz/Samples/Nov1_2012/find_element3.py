nums = [11, 323, 44, 55, 66, 55, 44, 33, 445, 677, 88, 23, 12]

value = input("Enter a number: ")

if value in nums: 
	print "Found"
else:
	print "Not found"

	


