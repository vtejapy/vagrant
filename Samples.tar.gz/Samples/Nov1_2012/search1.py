names = "john", "sam", "jane", "smith", "jones", "adam"
name = raw_input("Enter name: ")

found = False

for n in names:
    if n == name:
        found = True
        break

if found:
    print "Name found"
else:
    print "Name not found"

