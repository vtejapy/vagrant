from mathtools import isprime

nums = input("Enter upto last number: ")

for i in range(2, nums+1):
    if isprime(i): print i,


