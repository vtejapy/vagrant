while True:
    try:
        num = int(raw_input("Enter a number: "))
    except NameError, e:
        print "Invalid number, please enter again."
    except ValueError, e:
        print "Some error in value, please type again."
    except:
        print "Unknown error occurred, pleast type again."
    else:
        break

for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
    print num, "x", i, "=", num*i
    print "---------------------------" 

