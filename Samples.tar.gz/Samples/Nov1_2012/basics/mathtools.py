"""
  A simple utility module with math functions

  kldsjfkldsjflksdjfklsdjfklsdj flksdj flksdf
  sdlk flksdj fklsd jfklsdj fklsdjf
  sdlkfjsklfjslkfjsdlkjfsdlkjf slkjfslkdfj sdklfj sdl


"""


from math import sqrt

def isprime(num):
    """
        returns True if num is prime, else returns False
    
        >>> isprime(2)
        True

        >>> isprime(10)
        False

        >>> for i in range(2, 10): print isprime(i),
        True True False True False True False False

        >>> isprime(7)
        True

    """
    for i in range(2, int(sqrt(num))+1):
        if num % i == 0: return False 
    else:
        return True


if __name__ == '__main__':
    import doctest
    doctest.testmod()

