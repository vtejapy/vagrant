from math import sqrt

num = input("Enter a number: ")

for i in range(2, int(sqrt(num))+1):
    if num % i == 0:
        print num, "is not a prime number"
        break
else:
    print num, "is a prime number"

