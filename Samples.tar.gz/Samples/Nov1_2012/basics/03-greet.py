input = raw_input("Enter your name: ")
print "Hello", input

