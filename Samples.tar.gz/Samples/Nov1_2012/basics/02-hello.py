import sys

print "Hello",
print "World"
print >>sys.stderr, "Error message"
