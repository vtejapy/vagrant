#!/usr/bin/env python
a = "Hello"
b = raw_input("Enter a string: ") 

print "---", a, b, "---"
print id(a)
print id(b)

if a == b:
	print "Equal..."
else:
	print "Not equal..."


