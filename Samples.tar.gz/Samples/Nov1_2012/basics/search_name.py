names = "john", "sam", "jones", "jane", "adam", "smith", "bourne", "steve"

n = raw_input("Enter name to search: ")

if n in names:
    print n, "found"
else:
    print n, "not found"


#found = False
#for i in names:
#    if i == n:
#        found = True 
#        break
#
#
#if found:
#    print n, "found"
#else:
#    print n, "not found"


#for i in names:
#    if i == n:
#        print n, "found"
#        break
#else:
#     print n, "not found"







