query = """
   SELECT * FROM emp WHERE
            name = 'john' AND
            dept = 'IT'
"""

