#!/usr/bin/ruby
puts "Enter a number: "
num = gets.to_i

1.upto(10) {|i| 
   puts "#{num} x #{i} = #{num * i}"
}

