#!/bin/sh
while true
do
    echo "."
done

