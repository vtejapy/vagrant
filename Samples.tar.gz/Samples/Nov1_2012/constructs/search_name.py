names = "john", "alan", "smith", "joe", "bourne", "miller", "larry"

name = raw_input("Enter name to search: ")

found = False

for n in names:
    if n == name:
        found = True
        break


if found:
    print "Found"
else:
    print "not found"

