#!/usr/bin/env python

def foo():
	print "This is foo function"	

if __name__ == "__main__":
	foo()

