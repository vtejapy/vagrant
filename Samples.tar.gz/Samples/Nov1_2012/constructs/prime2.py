"""
  Check whether a number is prime or not.
"""
from math import sqrt

def is_prime(x):
    if x < 2: return False
    for i in range(2, int(sqrt(x))):
        if x % i == 0: 
            return False
    else:
        return True


nums = [44, 55, 66, 44, 667, 99, 87, 83, 22, 23, 27, 29, 31, 33]

#primes = filter(is_prime, nums)
#primes = map(is_prime, nums)
primes = [ x*x for x in nums if is_prime(x) ]

print primes

