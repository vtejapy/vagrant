names = "john", "alan", "smith", "joe", "bourne", "miller", "larry"

name = raw_input("Enter name to search: ")

if name in names:
    print "found
else:
    print "not found"

