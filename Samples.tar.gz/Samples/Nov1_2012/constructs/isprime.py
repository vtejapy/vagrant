"""
  Check whether a number is prime or not.
"""
from math import sqrt

def is_prime(x):
    if x < 2: return False
    for i in range(2, int(sqrt(x))):
        if x % i == 0: 
            return False
    else:
        return True

num = input("Enter a number: ")
if is_prime(num):
    print num, "is a prime number"
else:
    print num, "is not a prime number"

