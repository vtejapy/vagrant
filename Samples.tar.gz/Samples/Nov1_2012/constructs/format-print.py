people = (("John", 12),
          ("Smith", 11),
          ("Adrian", 16),
          ("Jones", 13),
          ("Bourne", 10))


format = "Name: %s, Age: %d"

for name, age in people:
    print format % (name, age)
    

