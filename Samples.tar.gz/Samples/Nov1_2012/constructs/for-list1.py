#!/usr/bin/env python
import sys

names = [ "john", "sam", "smith", "jones"]

name = raw_input("Enter a name: ")
if name in names:
	print "Found"
else:
	print "Not found..."
	

	
