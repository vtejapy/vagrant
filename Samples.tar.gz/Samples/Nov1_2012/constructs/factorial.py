""" 
Generate factorial of a number 
"""

#def factorial(n):
#    if n == 0: return 1
#    return n*factorial(n-1)

def factorial(n):
    fact = 1
    for i in xrange(1, n+1):
        fact *= i
    return fact

num = input("Enter number: ")
print factorial(num)


