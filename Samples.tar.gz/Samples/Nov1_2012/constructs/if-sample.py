#!/usr/bin/env python
num = input("Enter your age: ")
if num < 0:
	print "Which planet are you from ?!"

elif num >= 0 and num < 5:
	print "Too young to learn programming!" 
	print "Try LOGO, BASIC and so on..."

elif num >= 5 and num < 15:
	print "Welcome Young programmer..."
	print "Nice to meet you..."

elif num >= 15 and num < 80:
	print "Welcome Python Charmer..."
	print "What do you plan to learn today ?"

else:
	print "Isn't it time to retire from programming ?"
