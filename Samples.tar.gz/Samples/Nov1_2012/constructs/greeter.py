def greet():
    """
 This is greet() function.
 This function prints a greet message - 'Hello world'
    """       
    print "Hello world..."

