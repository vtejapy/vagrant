i = 0
while i < 10:
    print i
    i += 1
    if (i % 4) == 0:
        break
else:
    print "This is else block..."
    print "i = ", i
    

print "End of loop"
