#!/usr/bin/env python
print "Defining a function below..."

def int():
   print "This is foo() function"

int()
print "Foo function defined."

