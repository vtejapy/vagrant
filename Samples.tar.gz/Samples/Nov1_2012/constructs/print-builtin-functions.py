import __builtin__
import string

for i in dir(__builtin__):
	if i[0] in string.lowercase: print i

