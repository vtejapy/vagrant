print "Hello",
print "World"

