#!/usr/bin/env python

def getNameSpace():
	print __name__

getNameSpace()


