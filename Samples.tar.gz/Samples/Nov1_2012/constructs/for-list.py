#!/usr/bin/env python
import sys

names = [ [ "john", "sam", "smith", "jones"],
          [ "sarah", "larry", "williams", "steve"],
          [ "adrian", "adam", "bourne", "murdock" ] ]

name = raw_input("Enter a name: ")
for row in names:
	for n in row:
		if n == name:
			print "Found!"
			sys.exit(0)
		
	
