i, j = 0, 1

def foo():
    #print i, j
    #for i in range(10):
    i = 30
    j = i*20
    print i, j


foo()
print i, j

