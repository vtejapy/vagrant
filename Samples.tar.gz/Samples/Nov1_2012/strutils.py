
def find(haystack, needle, num):
    
    l = 0 
    index = 0
    for i in range(num):
        index = haystack.index(needle, index+l)
        l = len(needle)

    return index


def find(h, n, i):

    ind = -1
    while i != 0:
        ind = h.index(n, ind + 1)
        i -= 1

    return ind


