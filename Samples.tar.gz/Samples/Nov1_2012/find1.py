names = (("john", "sam", "jones"),
         ("sarah", "jane", "tom"),
         ("brian", "steve", "larry"))


n = raw_input("Enter name: ")

found = False

for row in names:
    if n in row: 
        found = True
        break

if found is True:
    print "Found"
else:
    print "Not found"

