from math import sqrt
def isprime(x):
    for i in range(2, int(sqrt(x))+1):
        if x % i == 0: return False
    else:
        return True

n = input("Enter number of series: ")
for i in range(n):
    if isprime(i): print i,


