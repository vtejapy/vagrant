try:
    num = int(raw_input("Enter a number: "))
except ValueError:
    print "Invalid number...."
except TypeError:
    print "Invalid type...."
except:
    print "Unknown error..."
else:
    for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
        print num, "x", i, "=", num*i
    exit(0)
finally:
    print "Cleanup done."

print "Program ended."


