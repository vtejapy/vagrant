print "Hello",
print "World"
