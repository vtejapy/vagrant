print "-" * 40
print " " * 8, "Hello world"
print "-" * 40

