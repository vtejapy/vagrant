for i in "john", "sam", 15, 45.67:
    print "Hello", i, "test", 100
    print "i"
        print "------------"

