def foo():
    def bar():
        print "This is bar function..."

    print "In foo function:"
    bar()


foo()
bar()

