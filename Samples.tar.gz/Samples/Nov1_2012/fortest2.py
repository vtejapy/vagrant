for i in 1, 2, 3, 4, 5:
    if i % 2 == 0:
        print i, "is even"
        j = i*100
        print "---------"
    del j

print "End of program"

print "i = ", i
print "j = ", j

