names = (("john", "sam", "jones"),
         ("sarah", "jane", "tom"),
         ("brian", "steve", "larry"))


n = raw_input("Enter name: ")

for row in names:
    if n in row: 
        print "Found"
        break
else:
    print "Not found"

