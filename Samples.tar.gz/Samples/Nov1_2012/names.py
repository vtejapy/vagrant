names = "john", "sam", "jones", "sarah", "adam"

n = raw_input("Enter name: ")

#for i in names:
#    if n == i:
#        print "Found"
#        break
#else: # for loop (run out of iterations)
#    print "Not found"

if n in names: 
    print "Found"
else:
    print "Not found"

