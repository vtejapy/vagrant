names = "john", "sam", "jane", "smith", "jones", "adam"
name = raw_input("Enter name: ")

for n in names:
    if n == name:
        print "Name found"
        break
else:
    print "Name not found"

