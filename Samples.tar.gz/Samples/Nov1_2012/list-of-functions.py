
def add_test(x, y):
	print "Adding x and y:", x + y
	return x + y

def mul_test(x, y):
	print "Multiplying x and y:", x * y
	return x * y

def div_test(x, y):
	print "Dividing x by y:", x / y
	return x / y

tests = [add_test, mul_test, div_test]

data = [(20, 10), (5, 2), (15, 5), (14, 7), (111, 11)]


for a, b in data:
     print "Tests on", a, b
     results = [ operation(a, b) for operation in tests ]
     print results
     print "-" * 10

