age = input("Enter your age: ")
if age < 0:
    print "Are you from planet earth."
elif age > 0 and age < 20:
    print "Hello young programmer"
elif age >= 20 and age < 80:
    print "Hello sir"
elif age > 80 and age < 150:
    print "Time to retire ?"
else:
    print "Which species do you belong to ?"
    print "sdkfklsdjflksdjflksdfj"

print "End of program"

