a = 0
while a < 10:
    
    a += 1
    if a % 2 == 0: continue

    print a
    if a % 5 == 0: break

else:
    print "a value is 10 or above"




