class Table {
	public static void main(String[] args) {

		if (args.length < 1) {
			System.out.println("usage: java Table <number>");
			System.exit(-1);
		}
		
		int num = Integer.parseInt(args[0]);

		for (int i=1; i<=10; i++) {
			System.out.println(num + " x " + i + " = " + (num*i));
		}
	}
}
