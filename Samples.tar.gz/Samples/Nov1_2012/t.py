#!/usr/bin/env python
def greet():
	print "Hello world"

