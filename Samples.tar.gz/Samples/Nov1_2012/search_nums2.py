nums = ((10, 20, 30), 44, 678, (44, 55, 66), (76, 54, 32))

n = input("Enter number: ")

for row in nums:
    if type(row) is not tuple: continue
    if n in row:
        print "Found"
        break
else:
    print "Not found"

print "End of program"

