nums = [11, 323, 44, 55, 66, 55, 44, 33, 445, 677, 88, 23, 12]

value = input("Enter a number: ")

for element in nums:
	if value == element: 
		print "Found"
		break
else:
	print "Not found"

	


