#!/usr/bin/env python

input = raw_input("Enter your name: ")

print input*10
