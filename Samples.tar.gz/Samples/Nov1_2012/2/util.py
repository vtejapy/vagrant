a = 100
name = "john"

def greet(x):
	print "Hello", x, "from", __name__

def square(x):
	return x*x

greet("john")



