range = xrange
import pdb
from time import sleep

def is_prime(x):
    sleep(0.2)
    for i in range(2, int(x**0.5)+1):
        if x % i == 0:
            return False
    else:
            return True

def gen_primes(n):
    primes = []
    i = 2
    while n:
        if is_prime(i):
            primes.append(i)
            n -= 1
        i += 1
    return primes

num = input("Enter a number: ")
for i in gen_primes(num):
    print i


