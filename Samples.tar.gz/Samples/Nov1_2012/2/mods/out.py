import sys

print "This is line 1"
print >>sys.stderr, "This is line 2"
raise TypeError, "Invalid type"

