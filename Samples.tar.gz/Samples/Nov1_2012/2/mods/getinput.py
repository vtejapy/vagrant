import sys

print "Enter a paragraph (^D to end / ^Z to end)"
print "-----------------------------------------"
data = sys.stdin.read()

print "Got data:", data

