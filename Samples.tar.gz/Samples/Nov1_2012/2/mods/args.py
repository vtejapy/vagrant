import sys

print "Arguments: ", sys.argv

for i in sys.argv:
    print "-->", i

