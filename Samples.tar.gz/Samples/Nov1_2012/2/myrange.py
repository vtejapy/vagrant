def myrange(start, stop):
    step = 1
    while start < stop:
        yield start
        start += step
        
