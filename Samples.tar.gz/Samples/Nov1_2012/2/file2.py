from genprime import gen_primes
# OUT: Welcome to genprime
list(gen_primes(10))
# OUT: [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
p = [ x*x for x in gen_primes(10) ]
p
# OUT: [4, 9, 25, 49, 121, 169, 289, 361, 529, 841]
names = "john", "sam", "jones", "adam", "smith", "adrian", "james", "jim", "bourne"
names
# OUT: ('john', 'sam', 'jones', 'adam', 'smith', 'adrian', 'james', 'jim', 'bourne')
a = "hello"
a.upper()
# OUT: 'HELLO'
dir(a)
# OUT: ['__add__', '__class__', '__contains__', '__delattr__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getnewargs__', '__getslice__', '__gt__', '__hash__', '__init__', '__le__', '__len__', '__lt__', '__mod__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__rmod__', '__rmul__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '_formatter_field_name_split', '_formatter_parser', 'capitalize', 'center', 'count', 'decode', 'encode', 'endswith', 'expandtabs', 'find', 'format', 'index', 'isalnum', 'isalpha', 'isdigit', 'islower', 'isspace', 'istitle', 'isupper', 'join', 'ljust', 'lower', 'lstrip', 'partition', 'replace', 'rfind', 'rindex', 'rjust', 'rpartition', 'rsplit', 'rstrip', 'split', 'splitlines', 'startswith', 'strip', 'swapcase', 'title', 'translate', 'upper', 'zfill']
a.upper()
# OUT: 'HELLO'
a
# OUT: 'hello'
names
# OUT: ('john', 'sam', 'jones', 'adam', 'smith', 'adrian', 'james', 'jim', 'bourne')
n = [ x.upper() for x in names ]
n
# OUT: ['JOHN', 'SAM', 'JONES', 'ADAM', 'SMITH', 'ADRIAN', 'JAMES', 'JIM', 'BOURNE']
names
# OUT: ('john', 'sam', 'jones', 'adam', 'smith', 'adrian', 'james', 'jim', 'bourne')
n = [ x for x in names if x[0] == 'j' ]
n
# OUT: ['john', 'jones', 'james', 'jim']
n = ( x for x in names if x[0] == 'j' )
n
# OUT: <generator object <genexpr> at 0x10222b910>
for i in n: print i

# OUT: john
# OUT: jones
# OUT: james
# OUT: jim
for n in ( x for x in names if x[0] == 'j' ): print n

# OUT: john
# OUT: jones
# OUT: james
# OUT: jim
for n in [ x for x in names if x[0] == 'j' ]: print n

# OUT: john
# OUT: jones
# OUT: james
# OUT: jim
n = ( x for x in names if x[0] == 'j' )
n = [ x for x in names if x[0] == 'j' ]
gen_primes(20)
# OUT: <generator object gen_primes at 0x10222bb90>
list(gen_primes(20))
# OUT: [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
from fib import fib
# OUT: Enter last number: 
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT:   File "fib.py", line 21, in <module>
# OUT:     num = input("Enter last number: ")
# OUT:   File "<string>", line 0
# OUT:    ^
# OUT: SyntaxError: unexpected EOF while parsing
from fibo import fibo
# OUT: Enter a number: 4
# OUT: 0 1 1 2Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: ImportError: cannot import name fibo
from fib import fibo
for i in fibo(10): print i,

# OUT: 0 1 1 2 3 5 8 13 21 34
n = [ x for x in fibo(100) if x % 3 == 0 ]
n
# OUT: [0, 3, 21, 144, 987, 6765, 46368, 317811, 2178309, 14930352, 102334155, 701408733, 4807526976, 32951280099, 225851433717, 1548008755920, 10610209857723, 72723460248141, 498454011879264, 3416454622906707, 23416728348467685, 160500643816367088, 1100087778366101931, 7540113804746346429, 51680708854858323072L]
n = [ x for x in fibo(100) if x % 3 == 0 ]
n
# OUT: [0, 3, 21, 144, 987, 6765, 46368, 317811, 2178309, 14930352, 102334155, 701408733, 4807526976, 32951280099, 225851433717, 1548008755920, 10610209857723, 72723460248141, 498454011879264, 3416454622906707, 23416728348467685, 160500643816367088, 1100087778366101931, 7540113804746346429, 51680708854858323072L]
sum(n)
# OUT: 60508827864880718400L
sum([x for x in xrange(1000) if x % 3 == 0 or x % 5 == 0])
# OUT: 233168
