def is_prime(x):
    for i in range(2, int(x**0.5)+1):
        if x % i == 0:
            return False
    else:
            return True

def gen_primes(n):
    i = 2
    while n:
        if is_prime(i):
#            print "Yielding from gen_primes..."
            yield i
#            print "Back to gen_primes()"
            n -= 1
        i += 1

print "Welcome to genprime"
a = 100
name = "john"

