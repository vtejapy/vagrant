def rev(items):
    l = len(items)
    while l > 0:
        l -= 1
        yield items[l]

