""" 
Generate fibonacci series upto the last number
The series would be something like below: 
   0, 1, 1, 2, 3, 5, 8, 13, 21, ...
"""

def fibo(n):
    a, b = 0, 1
    for i in range(n):
        yield a
        a, b = b, a + b


def fibo3(n):
    a, b = 0, 1
    while b < n:
        a, b = b, a+b
        print b,

def fibo2(n):
    series = [0, 1]
    for i in range(n-2):
        series.append(series[i] + series[i+1])

    return series

#num = input("Enter last number: ")
#print fibo2(num)

