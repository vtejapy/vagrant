#!/usr/bin/env python

if len(sys.argv) < 3:
    print "usage: ", sys.argv[0], " source destination."
    sys.exit(-1)

src = open(sys.argv[1])
dst = open(sys.argv[2], "w")
dst.write(src.read())
src.close()
dst.close()

