from sys import argv, stderr
from os.path import exists

def copyfile(source, destination):
    if not exists(source):
        print >>stderr, "%s: %s: No such file/directory" % (argv[0], source)
        return None

    if exists(destination):
        choice = raw_input(destination + " already exists. Overwrite (y/n) ? ")
        if choice[0] not in 'Yy' : return None

    #with open(source) as src:
    #    with open(destination, "w") as dst:
    #        dst.write(src.read())

    with open(source) as src, open(destination, "w") as dst:
        dst.write(src.read())


if len(argv) < 3:
    print >>stderr, "usage: %s source destination" % argv[0]
    exit(1)

source, destination = argv[1:]

copyfile(source, destination)


