#!/usr/bin/env python
import gzip
import sys

if len(sys.argv) < 3:
    print "usage: %s gzfile destination" % sys.argv[0]


gzFile = gzip.GzipFile(sys.argv[1])
contents = gzFile.read()
gzFile.close()

dst = open(sys.argv[2], "w")
dst.write(contents)
dst.close()

