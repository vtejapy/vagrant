#!/usr/bin/env python
import os.path 
from glob import glob
import sys
import os
import dircache

dir_list = []

def list(path):
    files = dircache.listdir(path)
    for file in files:
        file_path = path + os.sep + file
        if os.path.isdir(file_path):
            list(file_path)
        else:
            dir_list.append(file_path)

if len(sys.argv) < 2:
    path = "."
else:
    path = sys.argv[1]

list(path)
print dir_list





