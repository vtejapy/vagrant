#!/usr/bin/env python
from os.path import exists, isdir, isfile, islink
from glob import glob
import sys
import os

if len(sys.argv) < 2:
    path = "."
else:
    path = sys.argv[1]

if not isdir(path):
    print "%s: must be an existing folder"
    sys.exit(1)

for fname in glob(path + os.sep + "*"):
    print fname





