import sys
import os.path

program = sys.argv.pop(0)

if len(sys.argv) < 2:
    print >>sys.stderr, "usage: %s source [...] destination" % program
    exit(1)

destination = sys.argv.pop()



