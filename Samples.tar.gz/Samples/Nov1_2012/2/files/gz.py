#!/usr/bin/env python
import gzip
import sys

if len(sys.argv) < 3:
    print "usage: %s source gzfile" % sys.argv[0]

src = open(sys.argv[1])
contents = src.read()
src.close()

gzFile = gzip.GzipFile(sys.argv[2], "w")
gzFile.write(contents)
gzFile.close()

