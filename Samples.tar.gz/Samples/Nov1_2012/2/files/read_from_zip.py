import zipfile

myZipFile = zipfile.ZipFile( "test.zip", "r" )

for fileName in myZipFile.namelist():
    data = myZipFile.read(fileName)
    print fileName, len(data), repr(data[:50])

raw_input( '\n\nPress Enter to exit...' )
