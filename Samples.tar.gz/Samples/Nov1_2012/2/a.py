for i in range(10):
    print "Hello world"
    

# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
# OUT: Hello world
