def greet(name):
    print "Hello", name
    

greet("john")
# OUT: Hello john
greet("john", "sam")
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: greet() takes exactly 1 argument (2 given)
greet()
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: greet() takes exactly 1 argument (0 given)
def add(x, y): return x + y

add(10, 20)
# OUT: 30
add(10, 20, 30)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: add() takes exactly 2 arguments (3 given)
add(10
)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: add() takes exactly 2 arguments (1 given)
def greet(name="Guest"): print "Hello", name

greet()
# OUT: Hello Guest
greet("Sam")
# OUT: Hello Sam
greet("Sam", "dsfdsf")
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: greet() takes at most 1 argument (2 given)
def greet(name="Guest", city="Bengaluru"):
    print "Hello", name, ", Welcome to", city
    

greet()
# OUT: Hello Guest , Welcome to Bengaluru
greet("John")
# OUT: Hello John , Welcome to Bengaluru
greet("John", "Delhi")
# OUT: Hello John , Welcome to Delhi
greet("John")
# OUT: Hello John , Welcome to Bengaluru
greet("Delhi")
# OUT: Hello Delhi , Welcome to Bengaluru
greet(city="Delhi")
# OUT: Hello Guest , Welcome to Delhi
greet(city="Delhi", name="Sam")
# OUT: Hello Sam , Welcome to Delhi
greet("Delhi","Sam")
# OUT: Hello Delhi , Welcome to Sam
greet(city="Delhi", name="Sam")
# OUT: Hello Sam , Welcome to Delhi
def greet(name="Guest", city="Bengaluru", age):
    print "Hello", name, ", Welcome to", city, "Age: ", age
# OUT:   File "<input>", line 1
# OUT: SyntaxError: non-default argument follows default argument
def greet(age, name="Guest", city="Bengaluru"):
    print "Hello", name, ", Welcome to", city, "Age: ", age
    

greet()
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: greet() takes at least 1 argument (0 given)
greet(10)
# OUT: Hello Guest , Welcome to Bengaluru Age:  10
greet(10, "John")
# OUT: Hello John , Welcome to Bengaluru Age:  10
greet(10, "John", "Delhi")
# OUT: Hello John , Welcome to Delhi Age:  10
greet(10, "John", "Delhi", "sdfdsf")
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: greet() takes at most 3 arguments (4 given)
def greet(age, name="Guest", city="Bengaluru"):
    
    



    pass
    

def greet(age, name="Guest", city="Bengaluru"):
    print "Hello", name, ", Welcome to", city, "Age: ", age
    

greet(10)
# OUT: Hello Guest , Welcome to Bengaluru Age:  10
greet(10, "john")
# OUT: Hello john , Welcome to Bengaluru Age:  10
greet(name="john", age=10, city="delhi")
# OUT: Hello john , Welcome to delhi Age:  10
a
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: NameError: name 'a' is not defined
a = 11, 22, 33, 56, 78, 43
def add(x, y): return x + y

add(10, 20)
# OUT: 30
x, y = (10, 20)
def sumof(*numbers):
    print numbers
    total = 0
    for n in numbers: total += n
    return total
    

sumof(10, 20, 30)
# OUT: (10, 20, 30)
# OUT: 60
add(10, 20)
# OUT: 30
x, y = 10, 20
add(y=10, x=20)
# OUT: 30
sumof(10, 20, 30)
# OUT: (10, 20, 30)
# OUT: 60
sumof(10, 20, 30, 55, 66, 77, 88, 99, 44, 33)
# OUT: (10, 20, 30, 55, 66, 77, 88, 99, 44, 33)
# OUT: 522
sumof()
# OUT: ()
# OUT: 0
def greet(name, city="Delhi", *nums):
    print "Name = ", name
    print "City = ", city
    print "nums = ", nums
    

greet("john")
# OUT: Name =  john
# OUT: City =  Delhi
# OUT: nums =  ()
greet("john", "Pune")
# OUT: Name =  john
# OUT: City =  Pune
# OUT: nums =  ()
greet("john", "Pune", 67, 44, 33, 22, 5, 66, 77)
# OUT: Name =  john
# OUT: City =  Pune
# OUT: nums =  (67, 44, 33, 22, 5, 66, 77)
greet("john", "Pune", [67, 44, 33, 22, 5, 66, 77], 56)
# OUT: Name =  john
# OUT: City =  Pune
# OUT: nums =  ([67, 44, 33, 22, 5, 66, 77], 56)
a = 100
n = "john"
a = 10
b = 20
a = [10, 20, 30]
def square_list(x):
    
    pass
    

l
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: NameError: name 'l' is not defined
a = [10, 20, 30]
a
# OUT: [10, 20, 30]
a*10
# OUT: [10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30, 10, 20, 30]
a[0]*10
# OUT: 100
a
# OUT: [10, 20, 30]
dir(a)
# OUT: ['__add__', '__class__', '__contains__', '__delattr__', '__delitem__', '__delslice__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__getitem__', '__getslice__', '__gt__', '__hash__', '__iadd__', '__imul__', '__init__', '__iter__', '__le__', '__len__', '__lt__', '__mul__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', '__repr__', '__reversed__', '__rmul__', '__setattr__', '__setitem__', '__setslice__', '__sizeof__', '__str__', '__subclasshook__', 'append', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort']
a
# OUT: [10, 20, 30]
a ** 3
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: unsupported operand type(s) for ** or pow(): 'list' and 'int'
for i in range(len(a)):
    a[i] = a[i] * 10
    

a
# OUT: [100, 200, 300]
for i, v in enumerate(a):
    a[i] = v*v
    

a
# OUT: [10000, 40000, 90000]
def square_list(x):
    for i, v in enumerate(x):
        x[i] = v*v
        
    

a = [44, 55, 65, 1, 2, 5]
a
# OUT: [44, 55, 65, 1, 2, 5]
square_list(a)
a
# OUT: [1936, 3025, 4225, 1, 4, 25]
a
# OUT: [1936, 3025, 4225, 1, 4, 25]
x = a


def add_record(name, dept, city):
    print "Added record: name = ", name, ", dept =", dept, ", city = ", city
    

add_record("john", "IT", "Pune")
# OUT: Added record: name =  john , dept = IT , city =  Pune
rec = "john", "IT", "Pune"
rec
# OUT: ('john', 'IT', 'Pune')
add_record(rec)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: add_record() takes exactly 3 arguments (1 given)
add_record(rec[0], rec[1], rec[2])
# OUT: Added record: name =  john , dept = IT , city =  Pune
add_record(*rec)
# OUT: Added record: name =  john , dept = IT , city =  Pune
def add_record(name, dept, city):
    print "Added record: name = ", name, ", dept =", dept, ", city = ", city
    

add_record(*rec)
# OUT: Added record: name =  john , dept = IT , city =  Pune
add_record(*rec)
# OUT: Added record: name =  john , dept = IT , city =  Pune
rec
# OUT: ('john', 'IT', 'Pune')
rec = "john", "IT"
add_record(*rec)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: add_record() takes exactly 3 arguments (2 given)
sumof(11, 22, 33, 44, 55, 66, 77)
# OUT: (11, 22, 33, 44, 55, 66, 77)
# OUT: 308
a
# OUT: [1936, 3025, 4225, 1, 4, 25]
sumof(a)
# OUT: ([1936, 3025, 4225, 1, 4, 25],)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT:   File "<input>", line 4, in sumof
# OUT: TypeError: unsupported operand type(s) for +=: 'int' and 'list'
sumof(*a)
# OUT: (1936, 3025, 4225, 1, 4, 25)
# OUT: 9216
rec
# OUT: ('john', 'IT')
add_record(*rec)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: add_record() takes exactly 3 arguments (2 given)
add_record(name="john", dept="IT", city="Pune")
# OUT: Added record: name =  john , dept = IT , city =  Pune
add_record(name="john", dept="IT", city="Pune", country="India")
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: add_record() got an unexpected keyword argument 'country'
def add_record(**kwargs):
    print kwargs
    

add_record()
# OUT: {}
add_record(name="John")
# OUT: {'name': 'John'}
add_record(name="John", host="10.10.15.67")
# OUT: {'host': '10.10.15.67', 'name': 'John'}
add_record(name="John", host="10.10.15.67", user="john")
# OUT: {'host': '10.10.15.67', 'name': 'John', 'user': 'john'}
a
# OUT: [1936, 3025, 4225, 1, 4, 25]
a = range(10, 100, 5)
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
a[0]
# OUT: 10
s = "hello world"
s[0]
# OUT: 'h'
a[-1]
# OUT: 95
s[-1]
# OUT: 'd'
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
a[3]
# OUT: 25
a[3:8]
# OUT: [25, 30, 35, 40, 45]
id(a)
# OUT: 4406980976
b = a[3:8]
b
# OUT: [25, 30, 35, 40, 45]
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
id(a)
# OUT: 4406980976
id(b)
# OUT: 4407166736
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
b
# OUT: [25, 30, 35, 40, 45]
b = a[3:8]
b[0] = 100
b
# OUT: [100, 30, 35, 40, 45]
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
b = tuple(a)
b
# OUT: (10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95)
c = b[3:8]
c
# OUT: (25, 30, 35, 40, 45)
s
# OUT: 'hello world'
s1 = s[3:8]
s1
# OUT: 'lo wo'
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
len(a)
# OUT: 18
a[15:25]
# OUT: [85, 90, 95]
a[:4]
# OUT: [10, 15, 20, 25]
a[4:]
# OUT: [30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
a
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
id(a)
# OUT: 4406980976
b = a[:]
b
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
id(b)
# OUT: 4406861408
c = a
id(c)
# OUT: 4406980976
a[0] = 100
a
# OUT: [100, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
c
# OUT: [100, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
b
# OUT: [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
a
# OUT: [100, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95]
d = list(a)
id(d)
# OUT: 4407166736
id(a)
# OUT: 4406980976
a = [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
a[0]
# OUT: [10, 20, 30]
a[-1]
# OUT: 100
b = list(a)
id(a)
# OUT: 4406984504
id(b)
# OUT: 4407166448
a
# OUT: [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
b
# OUT: [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
a[0][0] = 100
a
# OUT: [[100, 20, 30], [40, 50, 60], [70, 80, 90], 100]
b
# OUT: [[100, 20, 30], [40, 50, 60], [70, 80, 90], 100]
a = 10
hash(a)
# OUT: 10
a = "hello"
hash(a)
# OUT: 840651671246116861
a = 10, 20, 30
a
# OUT: (10, 20, 30)
hash(a)
# OUT: -6299925204498084005
a = [10, 20, 30]
hash(a)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: unhashable type: 'list'
a
# OUT: [10, 20, 30]
a = ([10, 20, 30], 40, 50, 60)
hash(a)
# OUT: Traceback (most recent call last):
# OUT:   File "<input>", line 1, in <module>
# OUT: TypeError: unhashable type: 'list'
a
# OUT: ([10, 20, 30], 40, 50, 60)
a = [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
a
# OUT: [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
from copy import deepcopy
b = a[:]
c = deepcopy(a)
a
# OUT: [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
b
# OUT: [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
c
# OUT: [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
a[0][0] = 100
b
# OUT: [[100, 20, 30], [40, 50, 60], [70, 80, 90], 100]
c
# OUT: [[10, 20, 30], [40, 50, 60], [70, 80, 90], 100]
a = range(1, 20)
a
# OUT: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
a[2:6]
# OUT: [3, 4, 5, 6]
a[2:2:18]
# OUT: []
a[2:18:2]
# OUT: [3, 5, 7, 9, 11, 13, 15, 17]
a = range(100)
a
# OUT: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99]
a[20]
# OUT: 20
a[:20]
# OUT: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
a[1:20:2]
# OUT: [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
range(20)[1:20:2]
# OUT: [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
range(1, 20, 2)
# OUT: [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
a = [11, 22, 44, 55, 66, 77, 89, 43, 12, 54]
a
# OUT: [11, 22, 44, 55, 66, 77, 89, 43, 12, 54]
a[1::2]
# OUT: [22, 55, 77, 43, 54]
a[::2]
# OUT: [11, 44, 66, 89, 12]
a[::5]
# OUT: [11, 77]
a[::2+3]
# OUT: [11, 77]


a
# OUT: [11, 22, 44, 55, 66, 77, 89, 43, 12, 54]
b = []
for i in a: b.append(i*i)

b
# OUT: [121, 484, 1936, 3025, 4356, 5929, 7921, 1849, 144, 2916]
a
# OUT: [11, 22, 44, 55, 66, 77, 89, 43, 12, 54]
def sqr(x): return x*x

sqr(2)
# OUT: 4
b = map(sqr, a)
b
# OUT: [121, 484, 1936, 3025, 4356, 5929, 7921, 1849, 144, 2916]
a
# OUT: [11, 22, 44, 55, 66, 77, 89, 43, 12, 54]
p = (sqr, a)
p
# OUT: (<function sqr at 0x106a74ed8>, [11, 22, 44, 55, 66, 77, 89, 43, 12, 54])
map(*p)
# OUT: [121, 484, 1936, 3025, 4356, 5929, 7921, 1849, 144, 2916]
map
# OUT: <built-in function map>
a
# OUT: [11, 22, 44, 55, 66, 77, 89, 43, 12, 54]
b
# OUT: [121, 484, 1936, 3025, 4356, 5929, 7921, 1849, 144, 2916]
b = [ x*x for x in a ]
b
# OUT: [121, 484, 1936, 3025, 4356, 5929, 7921, 1849, 144, 2916]
from genprime import gen_primes
# OUT: Welcome to genprime
list(gen_primes(10))
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: Yielding from gen_primes...
# OUT: Back to gen_primes()
# OUT: [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
