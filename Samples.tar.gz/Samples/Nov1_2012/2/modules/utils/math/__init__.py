"""
    Math utility routines

    Contains a list of utility routines for
    math.
"""

name = "sam"
version = 1.0

class Test:
   """ A dummy test class
       
       This is a do-nothing class
   """
   pass

def cube(x):
    """
        Returns cube of parameter passed as x

        >>> cube(2)
        8

        >>> cube(3)
        27

        >>> cube("hello")
        Traceback (most recent call last):
        ...
        TypeError: invalid input parameter (require a number)

    """
    if type(x) not in (int, float, long):
        raise TypeError, "invalid input parameter (require a number)"
    else:
        return x*x*x


def fibo(x):
    """ 
        Create a fibonacci generator.
        x -> number of series to be generated
        Returns: a generator object.
    
        >>> for i in fibo(9): print i,
        0 1 1 2 3 5 8 13 21
    
    """
    a, b = 0, 1
    for i in range(x):
        yield a
        a, b = b, a + b

def square(x):
    """
       Returns square of parameter passed as x
       
       >>> square(2)
       4

       >>> square(3)
       9

    """
    return x*x

if __name__ == '__main__':
    import doctest
    doctest.testmod()






