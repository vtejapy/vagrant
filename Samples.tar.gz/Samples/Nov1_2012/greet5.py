#!/usr/bin/env python
name = raw_input("Enter your name: ")
age = raw_input("Enter your age: ")
age = int(age)

#print "Hello " + name + ",\nYou will live for another " + str(age*10) + " years"

print "Hello %s, \n You will live for another %d years" % name, age
