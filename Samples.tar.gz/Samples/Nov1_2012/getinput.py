#!/usr/bin/env python
import sys

contents = sys.stdin.read()

print contents.upper()

