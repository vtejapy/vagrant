a = 0
b = input("Enter divider value: ")
c = input("Enter last value: ");

while a < c:
    if a < b: continue
    
    if a % b == 0: print a,
    
    a += 1

    if a > 100: break

else:   # this is meant for while loop
    print "\nSkipping for values greater than", c



