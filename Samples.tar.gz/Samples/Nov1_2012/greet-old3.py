#!/usr/bin/env python
name = raw_input("Enter your name: ")
print "Hello " + name
age = raw_input("Enter your age: ")
age = int(age)

print "You will live for another " + str(age*10) + " years"

