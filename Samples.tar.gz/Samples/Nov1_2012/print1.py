#!/usr/bin/env python
a = -10
b = 65
result = "The square of %u is %d" % (a, a*a)

print "b is %c" % b

print result

