print "Hello world",
print 10, 20, 30, "john", "smith"

