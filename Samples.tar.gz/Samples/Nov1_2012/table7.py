import pdb
pdb.set_trace()

while True:
    try:
        number = int(raw_input("Enter a number: "))
        break
    except ValueError, e:
        print "*** Invalid number ***"
    

for i in 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
    print number, "x", i, "=", number*i
