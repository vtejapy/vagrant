from math import sqrt
def isprime(x):
    for i in range(2, int(sqrt(x))+1):
        if x % i == 0: return False
    else:
        return True

n = input("Enter a number: ")
if isprime(n):
    print n, "is a prime number"
else:
    print n, "is not a prime number"


