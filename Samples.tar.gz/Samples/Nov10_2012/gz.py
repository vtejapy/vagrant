import sys
import gzip

if len(sys.argv) < 3:
    print "usage: %s source-file gzip-file" % sys.argv[0]
    exit(1)


with open(sys.argv[1]) as src:
    with gzip.open(sys.argv[2], "w") as dst:
        dst.write(src.read())



