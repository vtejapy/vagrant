from multiprocessing.connection import Client

address = ('localhost', 6000)
conn = Client(address, authkey='abcd')
print conn.recv()                 
print conn.recv_bytes()            # => 'hello'
conn.close()
