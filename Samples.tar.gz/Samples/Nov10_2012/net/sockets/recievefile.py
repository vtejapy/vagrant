#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
import sys

def getfile(client):
	size = client.recv(10)
	data = client.recv(size)

	file = open("aaa.txt", "w")
	file.write(data)
	file.close()


mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.bind((sys.argv[1], int(sys.argv[2])))

mySocket.listen(5)

try:
	while True:
		(client, addr) = mySocket.accept()
		thread.start_new_thread(getfile, (client,))
except:
	mySocket.close()
	if client:
		client.close()


file = open(sys.argv[3])
contents = file.read()
file.close()

mySocket.send(contents)
reply = mySocket.recv(50)
print "Server acknowledged file: " + reply
mySocket.close()





