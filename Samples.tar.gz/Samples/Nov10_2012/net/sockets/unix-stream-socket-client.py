#!/usr/bin/env python
from socket import socket, AF_UNIX, SOCK_STREAM

mySocket = socket( AF_UNIX, SOCK_STREAM )
mySocket.connect("a.sock")


mySocket.send("This is a test string from client 1\n")

mySocket.close()


