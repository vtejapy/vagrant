#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
import sys

mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.connect((sys.argv[1], int(sys.argv[2])))

file = open(sys.argv[3])
contents = file.read()
file.close()

mySocket.send(contents)
reply = mySocket.recv(50)
print "Server acknowledged file: " + reply
mySocket.close()





