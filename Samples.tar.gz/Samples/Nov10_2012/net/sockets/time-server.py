#!/usr/bin/env python
from socket import socket, AF_INET, AF_UNIX, SOCK_DGRAM
import time

mySocket = socket( AF_INET, SOCK_DGRAM )
mySocket.bind( ("127.0.0.1", 5000) )

print "Time server started..."
while True:
    (data, addr) = mySocket.recvfrom(50) 
    print "Received time request from " + `addr`
    mySocket.sendto(time.ctime(), addr)


