#!/usr/bin/env python
from socket import socket, AF_INET, SOCK_STREAM
import thread
import re

def handle_connection(client):
	data = client.recv(1024)
	print "Header is -> ", data
	pattern = re.compile("^Filename: (\S+), Filesize: (\d+).*")
	matches = pattern.search(data)

	filename = matches.group(1)
	filesize = int(matches.group(2))
	contents = client.recv(filesize)

	outputfile = open("incoming/" + client.getpeername()[0] + "-" + filename, "w")
	outputfile.write(contents)
	outputfile.close()
	client.close()

		
mySocket = socket(AF_INET, SOCK_STREAM)
mySocket.bind(("127.0.0.1", 5050))

print "Echo server listening on port 5050\n"
mySocket.listen(5)

while True:
	(client, addr) = mySocket.accept()
	print "Got incoming connection from: " + `addr`
	thread.start_new_thread(handle_connection, (client,))







