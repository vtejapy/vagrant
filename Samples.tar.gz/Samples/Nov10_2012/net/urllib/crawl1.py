#!/usr/bin/env python
import sys
import urllib
import urllib2
import re

def fetch_url_list(url_string):
    web_request  = urllib2.urlopen(url_string)
    web_page     = web_request.read()
    href_pattern = re.compile("<\s*a\s+href\s*=\s*['\"](.*?)['\"](\s*>|\s)")
    url_tuple     = href_pattern.findall(web_page)
    url_list = []
    for (i, j) in url_tuple:
        url_list.append(urllib.basejoin(url_string, i))
        
    return url_list

def crawl(start_url):
    print start_url
    urls = fetch_url_list(start_url)
    for url in urls:
        crawl(url)



if len(sys.argv) < 2:
    print "usage: %s URL" % sys.argv[0]
    sys.exit(-1)

crawl(sys.argv[1])    
