from time import sleep
import sys

battery_status_file = "/proc/acpi/battery/BAT0/state"

try:
    with open(battery_status_file) as f:
        while True:
            f.seek(0, 0)
            for line in f:

                if line.startswith("present rate:"):
                    p = int(line.split(" ")[-2])
                    continue

                if line.startswith("remaining capacity:"):
                    r = int(line.split(" ")[-2])
                    break

            t = float(r) / p
            hours = int(t)
            minutes = int((t - hours) * 60)
            print "\rRemaining capacity: %2d hours, %2d mins" % (hours, minutes), 
            sys.stdout.flush()
            sleep(1)
except KeyboardInterrupt:
    print "\nBye bye."


