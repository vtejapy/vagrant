import os
from sys import argv, stderr

if len(argv) != 2:
   print >>stderr, "usage: %s path." % argv[0]
   exit(1)

path = argv[1]

size = 0
for dirpath, dirs, files in os.walk(path):
    for f in files:
        file_path = os.path.join(dirpath, f)
        size += os.path.getsize(file_path)

print "Size:", size, "bytes."






