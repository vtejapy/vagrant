import csv

c = csv.reader(open("a.csv"))
for row in c:
    fields = row[:3]
    if not fields[0]: continue
    print "Name: {0}, Age: {1}, City: {2}".format(*fields)


