from multiprocessing import Pool, Process

def square(x): return x*x

data = [10, 22, 33, 44, 55, 66, 77, 88, 99, 100]

p = Pool(10)
result = p.map(square, data)

#result = map(square, data)


print result

