from time import sleep
from multiprocessing import Process
from itertools import count

def foo(x):
    for i in count(0):
        print "Thread", x, "counting: ", i



tlist = { }

for i in range(10):
    tlist[i] = Process(target=foo, args=(i,))
    tlist[i].start()

