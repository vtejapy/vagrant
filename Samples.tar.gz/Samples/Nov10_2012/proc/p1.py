from time import sleep
from threading import Thread

def foo():
    for i in range(5):
        sleep(1)
        print "Foo counting: ", i


def bar():
    for i in range(5):
        sleep(1)
        print "Bar counting: ", i


t1 = Thread(target=foo)
t2 = Thread(target=bar)

t1.start()
t2.start()

for i in range(5):
    sleep(1)
    print "main counting: ", i

