from time import sleep
import sys

while True:
    print ".",
    sys.stdout.flush()
    sleep(1)

