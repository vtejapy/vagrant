import os
from time import sleep
from threading import Thread

def foo(name):
   for i in range(10):
       print "In", name, ": counting", i
       sleep(1)


def bar():
   for i in range(10):
       print "In bar: counting", i
       sleep(1)

p1 = Thread(target=foo, args=("Foofunction",))
p2 = Thread(target=bar)
p1.start()
p2.start()




        


