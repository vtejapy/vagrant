from time import sleep
import sys

for i in range(10):
   print ".",
   sys.stdout.flush()
   sleep(1)


