import os.path
from glob import glob

total = 0
for f in glob("*"):
    total += os.path.getsize(f)
 
print total



