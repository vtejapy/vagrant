with open("out") as a:
    print "File opened."
    raw_input("Press Enter to continue.\n")


