import os

ret = os.fork()

if ret == 0:
    os.execv("/bin/ls", ["/bin/ls", "/"])
else:
    print "Child forked, parent waiting..."
    os.wait()
    print "Child process complete..."


