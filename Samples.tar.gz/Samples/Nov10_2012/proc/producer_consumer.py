from time import sleep
from random import randint

def producer(pipe):
    while True:
        val = randint(10, 1000)
        print "producer: produced data %d\n" % val
        pipe.send(val)
        sleep(float(randint(1, 1000))/1000)


def consumer(pipe):
    while True:
        val = pipe.recv() 
        print "consumer: received %d\n" % val
        sleep(float(randint(1, 1000))/1000)


