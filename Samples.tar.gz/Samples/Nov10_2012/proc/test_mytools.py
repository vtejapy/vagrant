from multiprocessing import Process
from mytools import child_handler

p = Process(target=child_handler)

p.start()

