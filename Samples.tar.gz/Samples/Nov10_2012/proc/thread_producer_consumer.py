from threading import Thread
from producer_consumer import *
#from mypipe import Pipe

class Pipe:
    def __init__(self):
        from Queue import Queue
        self.queue = Queue(10)

    def send(self, v):
        self.queue.put(v)

    def recv(self):
        return self.queue.get()



p = Pipe()

t1 = Thread(target=producer, args=(p,))
t2 = Thread(target=consumer, args=(p,))

t1.start()
t2.start()

