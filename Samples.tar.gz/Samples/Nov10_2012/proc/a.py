import os

print "Running ls..."
os.system("ls")
print "Back to python..."


