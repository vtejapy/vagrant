from time import sleep

def child_handler():
    for i in range(10):
        print "Counting ", i
        sleep(1)

