from multiprocessing import Pool, Process
from time import sleep
from random import random, randint

data = [11, 22, 33, 55, 66, 65, 44, 22, 33, 55, 66, 77, 88, 99, 22, 33, 44, 55, 66]
p = Pool(10)

def square(x): return x*x

result = p.map(square, data)

print data
print result

