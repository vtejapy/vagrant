from multiprocessing import Pool, Process
from time import sleep
from random import random, randint

data = []
p = Pool(10)

def square(x): return x*x

def workers():
   global data
   while True:
      result = p.map(square, data[:])
      print result
      data = []
      sleep(random())

def populate_data():
    
    while True:
        data.append(randint(10, 100))  
        sleep(random())

p1 = Process(target=populate_data)
p2 = Process(target=workers)

p1.start()
p2.start()


