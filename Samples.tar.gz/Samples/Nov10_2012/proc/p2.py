from time import sleep
from threading import Thread
from itertools import count

def foo(x):
    for i in count(0):
        print "Thread", x, "counting: ", i



tlist = { }

for i in range(10):
    tlist[i] = Thread(target=foo, args=(i,))
    tlist[i].start()

