#total = 0
#with open("inventory.txt") as f:
#    for line in f:
#        if not line.strip(): continue
#        product, quantity, price = line.strip().split(":")
#        total += (int(quantity) * int(price))
#
#print total

#print [ line.strip().split(":")[-2:] for line in open("inventory.txt") ]
print sum([ int(x)*int(y) for x,y in [line.strip().split(":")[-2:] for line in open("inventory.txt")] ])
