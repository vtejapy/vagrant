#!/usr/bin/env python
import gzip
from sys import argv

if len(argv) < 3:
    print "usage: %s gzfile destination" % argv[0]
    exit(1)

with gzip.open(argv[1], "r") as src:
    with open(argv[2], "w") as dst:
        dst.write(src.read())


