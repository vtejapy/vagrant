from time import sleep
import sys
from os import getpid

print "Process: ", getpid()
a = []
for i in range(1000):
    b = range(10000000)
    a.append(b)
    for j in b: pass

    print ".",
    sys.stdout.flush()
    sleep(1)


