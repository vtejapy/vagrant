import os
from sys import argv, stderr
from time import time

if len(argv) < 2:
    print >>stderr, "usage: %s path." % argv[0]
    exit(1)


start = time()
for path, dirs, files in os.walk(argv[1]):
    for f in files:
        if f.endswith(".py"):
            print os.path.join(path, f)
end = time()

print "Duration: ", (end - start), "seconds"


