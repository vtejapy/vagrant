#!/usr/bin/env python
from glob import glob
import os

def read_link(f):
    try:
       path = os.readlink(f)
    except:
       path = ""

    if path.startswith("/"): 
       return path
    else:
       return ""
    

for f in sorted(set([ read_link(x) for x in glob("/proc/[0-9]*/fd/[0-9]*") ])):
    print f


   
