from os import walk
from sys import argv, stderr

if len(argv) < 2:
    print >>stderr, "usage: %s path." % argv[0]
    exit(1)

for path, dirs, files in walk(argv[1]):
    print "PATH = ", path
    print "-" * 40
    print "DIRS = ", dirs
    print "-" * 40
    print "FILES = ", files
    print "-" * 40
    raw_input("Press enter to continue...")
    print "=" * 40


