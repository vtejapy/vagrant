import pickle
a = [10, 20, 30]
name = "john"
info = {'name' : "sam", 'age' : 10, 'city' : 'Chennai' }

with open("pickled.dat", "w") as out:
    pickle.dump(a, out)
    pickle.dump(name, out)
    pickle.dump(info, out)

