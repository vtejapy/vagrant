# This connects to the openbsd ftp site and
# downloads the recursive directory listing.
import pexpect
child = pexpect.spawn('ftp ftp.chandrashekar.info', 
                       logfile=open("log.txt", "w"))
child.expect('Name .*: ')
child.sendline('testuser')
child.expect('Password:')
child.sendline('w3lc0me')
child.expect('ftp> ')
child.sendline('cd /www/files/python')
child.expect('ftp> ')

child.sendline('get may17.zip')
child.expect('ftp> ')

child.sendline('bye')
