import sys
import urllib
import urllib2

url = sys.argv[1]

response = urllib.urlopen(url)

print response.read(),


