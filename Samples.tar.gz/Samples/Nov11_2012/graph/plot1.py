import matplotlib.pyplot as plt

requests_per_second = [100, 30, 40, 600, 22, 11, 540]
time_intervals = [1, 2, 3, 4, 5, 6, 7]

for i, y in enumerate(requests_per_second):
    plt.bar(i, y)
  
#plt.plot(time_intervals, requests_per_second, 'ro')
plt.xlabel("Time interval (hour)")
plt.ylabel("Requests per second")

plt.axis([0, 10, 0, 1000])
plt.show()

