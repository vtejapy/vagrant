from wsgiref.validate import validator
from wsgiref.simple_server import make_server
from wsgiref.handlers import BaseHandler

class MyHandler(BaseHandler):
    def __init__(self, *args):
        print args

    def run(self, app):
        print "Got request for running app - ", app


def say_hello(environ, start_response):
    print "Got control to say_hello"

    start_response("200 OK", [("Content-Type", "text/plain")])
    return "<h1>Hello world</h1>"


httpd = make_server("", 8000, say_hello, handler_class=MyHandler)

httpd.serve_forever()

