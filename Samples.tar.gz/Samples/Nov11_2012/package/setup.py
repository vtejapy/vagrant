from distutils.core import setup
setup(name='MyUtils',
      version='1.0',
      description='A bunch simple functions and utilities',
      author='Chandrashekar Babu',
      author_email='chandrashekar.babu@gmail.com',
      url='http://www.chandrashekar.info/projects/myutils',
      py_modules = ['myutil']
     )

