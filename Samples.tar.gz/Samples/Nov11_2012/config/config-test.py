from ConfigParser import ConfigParser

config = ConfigParser()
config.read("myutils.ini")

print "Hostname: ", config.get("main", "host")
print "Port: ", config.get("main", "port")

print "Database: ", config.get("database", "dbname")

