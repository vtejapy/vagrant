
import myutil
import inspect

for i in inspect.getmembers(myutil):
    if not i[0].startswith("__"):
       if inspect.isclass(i[1]):
          class Car:


