"""
  This is a test module for trying out doctest

  >>> for i in range(2, 6): print square(i),
  4 9 16 25

"""

class Car:
    def drive(self):
        print "Driving car..."



def square(x):
    """
        return square of x
        
        >>> square(2)
        4

        >>> square(10)
        100

        >>> square("hello")
        Traceback (most recent call last):
        ...
        ValueError: parameter must be a number

    """
    if type(x) not in (int, float, long, complex):
        raise ValueError, "parameter must be a number"
    else:
        return x*x

def cube(x):
    """
        return cube of x

        >>> cube(2)
        8

        >>> cube(4)
        64

        >>> cube(3)
        27
        
        >>> cube([2, 3, 4])
        [8, 27, 64]

    """
    if type(x) is list:
        return [ n*n*n for n in x ]
    else:
        return x*x*x


if __name__ == '__main__':
    import doctest
    doctest.testmod()


