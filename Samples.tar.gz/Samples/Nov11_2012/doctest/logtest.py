import logging
MY_FORMAT="%(asctime)s: %(name)s: %(levelname)s: %(msg)s"

logging.basicConfig(format=MY_FORMAT)
logging.warning("this is a test warning")
logging.error("this is a test error message")
logging.debug("this is a debug message")

