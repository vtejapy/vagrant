def parse_users(filename):
    users = { }
    for record in open(filename):
        record = record.strip()
        if not record: continue
        username, password, fullname = record.split(":")

        users[username] = {
            'name'     : username,
            'password' : password,
            'fullname' : fullname
        }
    
    return users


