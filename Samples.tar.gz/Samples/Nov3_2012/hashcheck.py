class Car:

    def __hash__(self):
        return 100
    
    def __str__(self):
        return "Car object: " + self.name

    def __repr__(self):
        return "Car " + self.name


