car_data = { }

class Car:

    def __init__(self):
        car_data[id(self)] = { }
        print "Instantiated a car object"

    def __getattr__(self, attr):
        #print "Access of attribute: ", attr
        if attr not in car_data[id(self)]:
            raise AttributeError, "invalid attribute - " + attr
        return car_data[id(self)][attr]

    def __setattr__(self, attr, value):
        #print "Setting", attr, "to", value
        car_data[id(self)][attr] = value




