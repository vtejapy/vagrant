#!/usr/bin/env python
import sys

print len(sys.argv)

for arg in sys.argv:
   print arg
print "done"

