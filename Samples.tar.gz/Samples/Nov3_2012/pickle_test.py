class Car: pass

class Person: pass

import pickle

c = Car()
c.name = "Honda"
c.color = "Red"

p = Person()
p.name = "John"
p.age = 17

d = {"host" : "localhost", "port" : 8080}

with open("pickled.dat", "wb") as out:
    pickle.dump(c, out)
    pickle.dump(d, out)
    pickle.dump(p, out)

