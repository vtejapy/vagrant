import sys

for i in sys.argv:
    print i


