class Car: pass

class Person: pass

import pickle

with open("pickled.dat", "rb") as src:
    a = pickle.load(src)
    b = pickle.load(src)
    c = pickle.load(src)

print a
print b
print c

