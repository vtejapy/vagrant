import json

#json.dump(user_info, open("json.dat", "wb"))

d = json.load(open("json.dat", "rb"))
print d



