class Accumulator:

    def __init__(self):
        self.total = 0

    #def accumulate(self, v):
    #    self.total += v

    #def __call__(self): return self.total

    def __call__(self, v=None): 
        if v is None:
            return self.total
        else:
            self.total += v


