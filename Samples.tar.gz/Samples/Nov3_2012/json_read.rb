require 'json'
require 'pp'

d = JSON.load(open("json.dat"))

pp d

