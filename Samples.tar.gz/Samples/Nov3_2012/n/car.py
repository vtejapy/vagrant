class Car:

    def __init__(self, name="Honda", color="White"):
        self.name = name
        self.color = color

    def drive(self):
        print "Driving", self.name

    def get_info(self):
        for k, v in self.__dict__.items():
            if not callable(v): print k, "=", v


