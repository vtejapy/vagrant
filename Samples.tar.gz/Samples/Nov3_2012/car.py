class Car: pass


