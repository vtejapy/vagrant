class Car:

    def __init__(self):
        self.__dict__['__data__'] = { }
        print "Instantiated a car object"

    def __getattr__(self, attr):
        #print "Access of attribute: ", attr
        if attr not in self.__dict__['__data__']:
            raise AttributeError, "invalid attribute - " + attr
        return self.__dict__['__data__'][attr]

    def __setattr__(self, attr, value):
        #print "Setting", attr, "to", value
        self.__dict__['__data__'][attr] = value




