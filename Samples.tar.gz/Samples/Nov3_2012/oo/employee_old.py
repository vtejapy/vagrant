class Staff:

    def __init__(self, name):
        self.__dict__['properties'] = { 'name' : name }
        #print "Staff instance created."

    #def __setattr__(self, prop, value):
        #print "Setting", prop, "to", value
        if prop == 'name': raise AttributeError, "readonly property"
        self.__dict__['properties'][prop] = value

    def __getattr__(self, prop):
        #print "Getting value of", prop
        if prop == 'age': raise AttributeError, "cannot access this property"
        return self.__dict__['properties'][prop]

    
