class Vehicle:
    version = 1.0

    def __init__(self, name):
        print "Vehicle object created."
        self.name = name

    def drive(self):
        print "Driving", self.name

    def __del__(self):
        print "Vehicle removed:", self

class Car(Vehicle):
    def __init__(self, name):
        Vehicle.__init__(self, name)
        print "Car object created."


c1 = Car("Honda")

c1.drive()

