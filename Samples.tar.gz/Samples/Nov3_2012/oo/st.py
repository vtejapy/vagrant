from attr import Person
class Student(Person): pass

