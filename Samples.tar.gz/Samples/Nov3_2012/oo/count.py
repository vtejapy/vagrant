class Counter:

    def __init__(self, count=10):
        self.count = count
        self.i = 0

    def __iter__(self):
        return self

    def next(self):
        c = self.i
        self.i += 1
        if self.i > self.count: raise StopIteration
        return self.i

