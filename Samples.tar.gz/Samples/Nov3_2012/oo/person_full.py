class Person:
   
    def __init__(self, name=None, age=None, city=None):
        self.name, self.city = name, city
        self.__age = age

    def __call__(self, *x):
        print "Called this object as a function with params: ", x


    def __len__(self):
        return len(self.name)

    def __str__(self):
        return self.name

    def get_name(self):
        return self.name

    def get_age(self):
        return self.__age

    def set_name(self, name):
        self.name = name

    def __set_age(self, age):
        self.__age = age


     
