class People:

    def __init__(self, people):
       self.people = people
       self.index = 0

    def __iter__(self): return self

    def next(self):
        if self.index < len(self.people):
            self.index += 1
            return self.people[self.index-1]
        else:
            raise StopIteration
         

