class World:
    __properties = { } # Borg singleton

    def __init__(self):
      self.__dict__ = World.__properties  

#    __instance = None

#    def __new__(cls, *args, **kwargs):
#        print "new method called..."
#        if not World.__instance:
#            print "Creating new instance..."
#            World.__instance = super(World, cls).__new__(cls, *args, **kwargs)
#
#        return World.__instance

#    def __init__(self):
#        if not World.__instance:
#            World.__instance = self
#        else:
#            raise ValueError, "already instantiated"

#    def __call__(self):
#        return self.__instance


