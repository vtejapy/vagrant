data = { }

class Car:

    def __init__(self, name="Toyota"): # Initializer method
        print "Creating car instance..."
        data[id(self)] = { }
        self.name = name

    def drive(self):
        print "Driving car", self.name

    def __del__(self):
        print "Object", self, "destroyed"

    #def __str__(self):
    #    return "Car instance: name =" + self.name

    def __add__(self, other):
        newcar = Car()
        newcar.name = self.name + other.name
        return newcar

    def __setattr__(self, name, value):
        #print "Setting", name, "to", value
        data[id(self)][name] = value

    def __getattr__(self, name):
        #print "Trying to access", name
        return data[id(self)][name]

if __name__ == '__main__':
    c1 = Car()
    #Car.__new__(Car, Object, *args, **kwargs)
    #    --> Car.__init__(obj, *args, **kwargs)
    #                     obj --> c1
    c1.drive() # c1.__class__.drive(c1)

