class Person:
    private_members = ['salary', 'phone']

    def __init__(self, name="John", salary=100000, phone=343434):
        self.__dict__['name'] = name
        self.__dict__['salary'] = salary
        self.__dict__['phone'] = phone

    def __getattr__(self, prop):
        return self.__dict__[prop]


    def __setattr__(self, prop, value):
        if prop not in Person.private_members:
            self.__dict__[prop] = value
        else:
            raise NameError, "Cannot set private property - %s" % prop


