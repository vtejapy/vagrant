class Cycle:

    def __init__(self, data):
        self.data = data
        self.i = 0

    def __iter__(self):
        return self

    def next(self):
        v = self.data[self.i]
        self.i += 1
        if self.i >= len(self.data): self.i = 0 
        return v

if __name__ == '__main__':
    names = "john", "sam", "smith", "steve"

    c = Cycle(names)
    for i in c: print i


