class Square:

    def __init__(self):
        self.nums = []

    def __call__(self, *args):
        if len(args) > 0:
            x = args[0]
            self.nums.append(x)
            return x*x
        else:
            return self.nums


