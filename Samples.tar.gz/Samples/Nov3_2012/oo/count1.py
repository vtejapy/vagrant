def counter(x=10):
   i = 0
   while i < x:
       yield i
       i += 1

