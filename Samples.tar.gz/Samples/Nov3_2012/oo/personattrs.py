store = { }

class Person:
   
    def __init__(self, name=None, age=None, city=None):
        global store
        store = {'name' : name, 'age' : age, 'city' : city }

    def __getattr__(self, prop):
        print "getattr called with", prop
        if prop in store:
           return store[prop]
        else:
           raise NameError, prop + ": does not exist."

    def __setattr__(self, prop, value):
        print "setattr called with", prop, "set to", value
        if prop == "age":
            raise ValueError, "cannot set this property"
        else:
            store[prop] = value
 
