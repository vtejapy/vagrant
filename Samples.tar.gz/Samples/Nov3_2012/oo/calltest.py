class Person:

    def __init__(self, name="sam", city="Delhi"):
        self.name, self.city = name, city
        self.__salary = 10000000000

    def __call__(self, *args):
        print "Name: %s, City: %s" % (self.name, self.city)

    def __private_method(self):
        print "This is a private method..."

