def cycle(data):
    l = len(data)
    i = 0
    while True:
         yield data[i]
         i += 1
         i %= l
