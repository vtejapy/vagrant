class Staff:

    def __init__(self, name):
        self.name = name
        print "Staff instance created."

    def __str__(self):
        return self.name

    def __repr__(self):
        return '{ "name" : "%s" }' % self.name

    def __len__(self):
        return 100

