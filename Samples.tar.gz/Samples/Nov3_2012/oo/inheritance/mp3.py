from e import ElectronicDevice
from m import MusicPlayer

class MP3Player(ElectronicDevice, MusicPlayer):

    def __init__(self, name="ipod"):
        self.name = name

    def buy(self):
        MusicPlayer.buy(self)
        ElectronicDevice.buy(self)

m = MP3Player()

m.buy()

#m.poweron()
#m.play()
#m.stop()
#m.poweroff()


