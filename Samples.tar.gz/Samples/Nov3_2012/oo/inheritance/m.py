class MusicPlayer:

    def play(self):
        print self.name, "playing..."

    def stop(self):
        print self.name, "stopped..."

    def buy(self):
        print "bought a music player."

