class Accumulator:

    def __init__(self):
        self.nums = []

    def __call__(self, *args):
        if len(args) > 0:
            self.nums.append(args[0])
        else:
            return sum(self.nums)


