def fibogen(x=10):
    a, b = 0, 1
    while x > 0:
        yield a
        a, b = b, a + b
        x -= 1

