user_info = {
    "name"     : "root",
    "password" : "root123", 
    "home" : "/root", 
    "shell" : "/bin/bash",
    "access" : {
                "/etc" : "read-write",
                "/var" : "read-only"
     },
     "roles" : ("superuser", "backup", "devel", "admin")
}

import json

json.dump(user_info, open("json.dat", "wb"))



