class Car:
    __price = 10000000 # Class attribute

    def __init__(self, name, color="Black"):
        print "Instantiated a car object:", name
        self.name = name       # instance attributes
        self.color = color
        self.__owner = "Sam"

    def __del__(self):
        print "Del method called on", self.name

    def __add__(this, other):
        return Car(name=this.name + other.name)

    def __eq__(this, other):
        return this.price == other.price

    def drive(self, c=None): # Instance method
        print "Driving", self.name
        print "Owner: ", self.__owner
        self.__getinfo()
        if c is not None:
            print id(c), id(self)

    def __getinfo(self):
        print "Getting information of", self.name
        self.__price

if __name__ == '__main__':
    c1 = Car(name="Honda", color="Red")
    c2 = Car("Toyota")

    c1.drive()
    c2.drive()

    c1.drive(c1)

