
def iterator(data, c):
    for i in data:
        if i.startswith(c): yield i


data = "sam", "john", "adam", "jane", "adrian", "jones", "smith", "jim"

for n in iterator(data, "j"):
    print n


