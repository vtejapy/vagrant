class Iterator:

    def __init__(self, data, c):
        self.data = data
        self.c = c
        self.i = 0

    def __iter__(self):
        return self

    def next(self):
        if self.i >= len(self.data):
            raise StopIteration

        while self.i < len(self.data):
            found = None
            if self.data[self.i].startswith(self.c): 
                found = self.data[self.i]
            self.i += 1
            if found: return found

data = "sam", "john", "adam", "jane", "adrian", "jones", "smith", "jim"

for i in Iterator(data, "j"):
    print i



