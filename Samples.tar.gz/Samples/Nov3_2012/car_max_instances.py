class Car:
    instances = 4

    def __init__(self):
        if not Car.instances:
            raise ValueError, "cannot instantiate any more objects."
        else:
            Car.instances -= 1
            print "Instantiated a car object"


    def __del__(self):
        Car.instances += 1

