#!/usr/bin/env python
from time import sleep
import sys

if len(sys.argv) < 2:
   print "usage: %s PID" % sys.argv[0]
   exit(1)

with open("/proc/%s/status" % sys.argv[1]) as status:
    while True:
        status.seek(0)
        for line in status.xreadlines():
            if "VmRSS" in line:
               print "\r", line.split(":")[1].strip(), 
               sys.stdout.flush()
               break
        sleep(1)




