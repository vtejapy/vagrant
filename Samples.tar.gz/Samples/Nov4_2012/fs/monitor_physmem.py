#!/usr/bin/env python
from time import sleep
import sys
from glob import glob

def get_rss_usage(f):
   with open(f) as status:
       for line in status.xreadlines():
           if "VmRSS" in line:
               return int(line.split(":")[1].strip().split(" ")[0])
       else:
           return 0
try:
   while True:
      for f in glob("/proc/[0-9]*/status"):
          total += get_rss_usage(f)
      print "\r", total, 
      sys.stdout.flush()
      sleep(1)
except KeyboardInterrupt:
   print "\nExited."





