import os.path
from glob import glob
import sys

if len(sys.argv) < 2: 
   path = "."
else:
   path = sys.argv[1]


print sum([ os.path.getsize(f) for f in glob(path + "/" + "*") ])

