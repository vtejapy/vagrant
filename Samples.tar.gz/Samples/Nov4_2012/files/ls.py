#!/usr/bin/env python
import dircache
import sys

if len(sys.argv) < 2:
   path = "."
else:
   path = sys.argv[1]

for file in dircache.listdir(path):
   print file



