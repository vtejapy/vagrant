#!/usr/bin/env python
import re

pattern = re.compile("\d+")
input_str = raw_input("Enter a string: ")
list_of_numbers = pattern.findall(input_str)

for num in list_of_numbers:
    print num
    



