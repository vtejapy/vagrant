#!/usr/bin/env python
import sys
import re

if len(sys.argv) < 3:
    sys.stderr.write("usage: %s string file.\n" % sys.argv[0])
    exit(1)

search_string = sys.argv[1]
filename = sys.argv[2]

print "Searching for %s in %s..." % (search_string, filename)

pattern = re.compile(search_string)

with open(filename) as file:
    contents = file.read()

match = pattern.search(contents)
if match is not None: 
    print "%s matched in %s at indices %d:%d" % (search_string,
            filename,match.start(), match.end())
else:
    print "%s NOT found in %s" % (search_string, filename)



