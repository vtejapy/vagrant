#!/usr/bin/env python
import re

pattern = re.compile("^\d{6,}$")

while True:
    input = raw_input("Enter a string: ")
    match = pattern.search(input)
    if match:
        m = input[match.start():match.end()]
        print "Match found: ", m        
    else:
        print "NO Match found!"
