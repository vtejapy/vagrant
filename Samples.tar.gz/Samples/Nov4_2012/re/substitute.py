#!/usr/bin/env python
import sys
import re

# python substitute.py this that a.txt b.txt

if len(sys.argv) < 3:
   print "usage: %s pattern replacement source-file dest-file." % sys.argv[0]
   exit(1)

pattern = re.compile(sys.argv[1])
replacement, source, destination = sys.argv[2:]

with open(source) as src:
     with open(destination, "w") as dst:
         for line in src.xreadlines():
             dst.write(pattern.sub(replacement, line))

