#!/usr/bin/env python
import sys
import re

f = open("results.html")
lines = f.read()
f.close()

pattern = re.compile("<\s*a\s+href\s*=\s*['\"](.*?)['\"]\s*>")
urls = pattern.findall(lines)

for i in urls:
	print "--> ", i


	





	





