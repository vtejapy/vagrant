#!/usr/bin/env python
import sys
if len(sys.argv) < 3:
    sys.stderr.write("usage: %s string file.\n" % sys.argv[0])
    exit(1)

search_string = sys.argv[1]
filename = sys.argv[2]

print "Searching for %s in %s..." % (search_string, filename)

with open(filename) as file:
    contents = file.read()

index = contents.find(search_string)
if index >= 0:
    print "%s found in %s at index %d" % (search_string, filename, index)
else:
    print "%s NOT found in %s" % (search_string, filename)



