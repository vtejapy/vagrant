#!/usr/bin/env python
import sys
import re

regex = raw_input("Enter regular expression pattern: ")

try:
    while True:
        data = raw_input("Enter string: ")
        match = re.search(regex, data)
        if match:
            print "Match found: '%s' (%d:%d)" % (match.group(), match.start(), match.end())
        else:
            print "Match NOT found"
except:
    print "Bye"

