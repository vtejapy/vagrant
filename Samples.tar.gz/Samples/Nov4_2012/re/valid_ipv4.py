#!/usr/bin/env python
import sys
import re

pattern = r"""
    \b(
    0\.0\.0\.0 |     # match 0.0.0.0 or
    (                # match leading octet (1 to 255)
      [1-9]    |     # match 1 to 9 or
      [1-9]\d  |     # match 10 to 99 or
      1\d\d    |     # match 100 to 199 or
      2[0-4]\d |     # match 200 to 249 or
      25[0-5]        # match 250 to 255
    )
    (                # match other octets (0 to 255)
      \.             # match .
      (
         \d       |  # match 0 to 9 or
         [1-9]\d  |  # match 10 to 99 or
         1\d\d    |  # match 100 to 199 or
         2[0-4]\d |  # match 200 to 249 or
         25[0-5]     # match 250 to 255
      )
    ){3}             # match thrice for other 3 octets
    )\b
"""

try:
    while True:
        data = raw_input("Enter IPv4 address (x.x.x.x): ")
        match = re.search(pattern, data, re.VERBOSE | re.DEBUG)
        if match:
            print "Extracted valid IPv4 address: ", match.group()
        else:
            print "Could NOTextract valid IPv4 address"
except:
    print "Bye"

