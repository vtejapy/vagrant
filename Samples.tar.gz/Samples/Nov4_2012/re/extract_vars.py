#!/usr/bin/env python
import sys
import re
import pdb

regex = "([A-Za-z_]\w*)\s*=\s*(\d+)"
pattern = re.compile(regex)

while True:
    data = raw_input("Enter string: ")
    match = pattern.search(data)
    if match:
        print "Match found: var = %s, value = %s" % (match.group(1), match.group(2))
#        pdb.set_trace()
    else:
        print "Match NOT found"

