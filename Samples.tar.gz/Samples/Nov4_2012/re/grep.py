#!/usr/bin/env python
import sys
import re

if len(sys.argv) < 3:
   print "usage: %s string file.\n" % sys.argv[0]
   exit(1)

with open(sys.argv[2]) as src:
   for line in src.xreadlines():
       if re.search(sys.argv[1], line):
          print line,

