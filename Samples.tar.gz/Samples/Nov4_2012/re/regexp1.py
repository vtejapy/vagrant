#!/usr/bin/env python

import re
pattern = re.compile('is')
matches = pattern.search("This is a test string")
if matches:
	print matches.group()

