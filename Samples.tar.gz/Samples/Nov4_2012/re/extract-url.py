#!/usr/bin/env python
import re
import sys
import urllib

pattern = re.compile("<\s*a\s+href\s*=\s*['\"](http://.*?)['\"]\s*.*?>")

if len(sys.argv) < 2:
	print "usage: python extract-url.py filename"
	sys.exit(1)
	
with open(sys.argv[1]) as f:
    contents = f.read()
	

for match in pattern.finditer(contents):
	url = match.groups()[0]
	print url	
