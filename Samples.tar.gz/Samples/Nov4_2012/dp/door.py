class Door:
    def open(self):
        print "Door opened..."

    def close(self):
        print "Door closed..."

    def lock(self):
        print "Door locked..."

