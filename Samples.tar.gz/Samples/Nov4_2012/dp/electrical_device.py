class ElectricalDevice:

    properties = set(['poweron', 'poweroff'])

    def __init__(self, device):
        d = device()
        #if hasattr(d, 'poweron') and hasattr(d, 'poweroff'):
        if set(dir(d)).issuperset(ElectricalDevice.properties):
            self.device = d
        else:
            raise TypeError, 'not an electrical device...'

    def __getattr__(self, prop):
         return getattr(self.device, prop)


        
