class Lightbulb:
    def poweron(self):
        print "Lightbulb powered on..."

    def poweroff(self):
        print "Lightbulb powered off..."
