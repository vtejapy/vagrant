import types

class Openable:
    properties = set(["open", "close"])

    def __init__(self, target):
        if type(target) is types.InstanceType:
            obj = target
        elif type(target) is types.ClassType:
            obj = target()

        if set(dir(obj)).issuperset(Openable.properties):
            self.obj = obj
        else:
            raise TypeError, "not an openable object"

    def __getattr__(self, prop):
        return getattr(self.obj, prop)
           
