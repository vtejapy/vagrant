def manufacture(type):
    
    if type == 2:
        class Bike:
            def buy(self):
                print "Buying bike..."

            def ride(self):
                print "Riding bike...."
        return Bike()

    elif type == 3:
        class AutoRickshaw:
            def buy(self):
                print "Buying auto..."

            def drive(self):
                print "Driving auto...."
        return AutoRickshaw()

    elif type == 4:
        class Car:
            def buy(self):
                print "Buying car..."

            def drive(self):
                print "Driving car...."
        return Car()


