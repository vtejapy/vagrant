def foo(): print "foo function welcomes you"
