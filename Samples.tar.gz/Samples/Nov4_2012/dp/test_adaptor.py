from adaptor_test import Fan, Lightbulb, ElectricalDevice, Laptop, Marker

e1 = ElectricalDevice(Fan)
e2 = ElectricalDevice(Lightbulb)
e3 = ElectricalDevice(Laptop)
e4 = ElectricalDevice(Marker)


e1.poweron()
e2.poweron()
e3.poweron()

print e1
print e2
print e2


