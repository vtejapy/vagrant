#print "Hello",
#print "World"

import sys

sys.stdout.write("Hello")
sys.stdout.write("World")

