import sys

print "Enter a paragraph. Type EOF to exit."
contents = sys.stdin.read()

print "-" * 30
print contents.upper()

