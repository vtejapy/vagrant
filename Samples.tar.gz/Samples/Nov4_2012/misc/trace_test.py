import sys

def baz():
    print "baz..."

def bar():
    print "bar..."
    baz()

def foo():
    print "foo..."
    bar()

def print_info(*args):
    print "Entered function: ", args

sys.settrace(print_info)

foo()


